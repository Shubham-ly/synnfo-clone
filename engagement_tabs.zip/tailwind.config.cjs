const config = {
  content: ["./src/**/*.{html,js,svelte,ts}"],

  theme: {
    extend: {
      colors: {
        accent: "#fe5814",
      },
      screens: {
        md: "900px",
      },
      maxWidth: {
        screen: "100vw",
      },
    },
  },

  plugins: [],
};

module.exports = config;
